import React from "react";
import SidebarAndNavbar from "./SidebarAndNavbar";
const EditProfilePage = () => {
  return (
    <div className="EditProfilePage">
      <SidebarAndNavbar />
    </div>
  );
};

export default EditProfilePage;
